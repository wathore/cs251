#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<pthread.h>
#include <unistd.h>
#include<string.h>
#include<math.h>
float acco[10000];


pthread_mutex_t lock;

void account_array(int j,int cnt,char numb[40]){

int i;
float real_number=0;
for( i=0;i<=cnt;i++){
int d = (int) (numb[i]);
 if(d == 46)
   break;
}
 float power=1;
 for(int k=i-1;k >= 0;k--){
  real_number=real_number + power * ((int) ((numb[k])-48));
 power=power*10;

}
power=0.1;
for(int k=i+1;k<=cnt;k++)
 {
  real_number=real_number + power * ((int) ((numb[k])-48));
  power=power*0.1;

 }
acco[j]=real_number;
//printf("%d %f\n",j,real_number);

}

float get_number(int cnt,char numb[40]){


int i;
float real_number=0;
for(i=0;i<=cnt;i++){
int d = (int) (numb[i]);
 if(d == 46)
   break;
}
 float power=1;
 for(int k=i-1;k >= 0;k--){
  real_number=real_number + power * ((int) ((numb[k])-48));
 power=power*10;

}
power=0.1;
for(int k=i+1;k<=cnt;k++)
 {
  real_number=real_number + power * ((int) ((numb[k])-48));
  power=power*0.1;

 }

return  real_number;


}


void* calculate(void *arg)
{
 float trans_number=0,trans_type=0,amount=0,acc1=0,acc2=0;
 int index=0,count=0;
 pthread_mutex_lock(&lock);   
char *c = (char*)(arg);
char numb[40];
//printf("%c",*c);

for(int i=0;1;i++){
int d = (int) *(c+i);
if(d==10) //newline
 break;

if(d==32){ //space
 if(count==0)
     trans_number=((int)numb[0])-48;
 else if(count==1)
    trans_type=((int)numb[0])-48;
 else if(count==2)
   amount=get_number(index-1,numb);
 else if(count==3)
  acc1=get_number(index-1,numb);
  else
 acc2=get_number(index-1,numb);
index=0;
count++;
continue;
}



numb[index]= *c;
index++;




//printf("%c",*(c+i));
}

printf("trans_number=%f,trans_type=%f,amount=%f,acc1=%f,acc2=%f",trans_number,trans_type,amount,acc1,acc2);

printf("\n");

pthread_mutex_unlock(&lock);
pthread_exit(NULL);
}






















int main(int argc, char **argv)
{
     int fd, ctr,thread,number_trans;
     unsigned long size, bytes_read = 0, hash_count;
     char *buff,*cbuff;
     unsigned long *hashes;
     char c,account[10000][40],nomb[40];

     if(argc != 5){
            printf("Usage: %s <fileneme>\n", argv[0]);
            exit(-1);         
      } 
     FILE *f = fopen(argv[1], "r"); 
     fd = open(argv[2], O_RDONLY);
     thread=atoi(argv[4]);
     pthread_t threads[thread];
     number_trans=atoi(argv[3]);
     if(fd < 0){
           printf("Can not open file\n");
           exit(-1);
     } 
    
    size = lseek(fd, 0, SEEK_END);
    
    if(lseek(fd, 0, SEEK_SET) != 0){
           perror("lseek");
           exit(-1);
    }
   
    buff = malloc(size);
    if(!buff){
           perror("mem");
           exit(-1);
    }   
   /*Read the complete file into buff
     XXX Better implemented using mmap */
   
    do{
         unsigned long bytes;
         cbuff = buff + bytes_read;
         bytes = read(fd, cbuff, size - bytes_read);
         if(bytes < 0){
             perror("read");
             exit(-1);
         }
        bytes_read += bytes;
     }while(size != bytes_read);
   int cnt=0,index=0,flag=0;    
  for(unsigned long  i=0;i<200000;i++){
    c= (char)fgetc(f);
    int d = (int) c;
      if(d == 0 || d == 26 || d == -1 )
        break;
      if(d == 10) //new-line
      {
        cnt++;
        index=0;
        flag=0;
      }    
       if(flag==1 && ( (d >= 48 && d <= 57) || d == 46)){
         account[cnt][index] = c;
          // printf("%c",account[cnt][index]);
          index++;
         
        }
      if(d == 32){ //space
        flag=1;
        // printf("\n");
      }
   }
  int d=48,cont=0;
 for(int i=0;i<10000;i++)
   {
     cont=0;
     for(int j=0;j<40;j++){
        d = (int) account[i][j];
         if(d == 0 || d == 26 || d == -1 )
        break;
      
        if((d >= 48 && d <= 57) || d == 46){
       nomb[cont]=account[i][j];
         //printf("%c",account[i][j]);
        cont++;}
        else
         continue;
      }
    // printf("*%d %d\n",i+1001,cont-1);
    account_array(i,cont-1,nomb);
   }

int flags=1;
for(int i=0;i<size;i++){
    int d = (int)(*(buff+i));  
      //printf("%c",*(buff+i));
  if(flags==1){
     //printf("%c\n",*(buff+i));
     if(pthread_create(&threads[i%thread], NULL, calculate, buff+i)!=0){
      perror("pthread_create");
              exit(-1);
        }
 
     flags=0;
  }
 if(d == 10)
    flags=1;
}

 



//printf("%d %d",thread,number_trans);


























  return 0;
}


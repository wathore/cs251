#!/usr/bin/python

import sys
from decimal import Decimal
n=sys.argv[1];
b=int(sys.argv[2]) ;
count=0;
arr =['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']



def index(n):
 i=1
 if(dott!=0 and n==1):
  return k;
 if(dott!=0):
  n=n+1;
 for x in range(0,n-1):
  i=i*k
 return i;

value=len(n);
length=len(n);
minus=0
k=b;
dot=0;
dott=0
for digit in n:
 if(digit=="."):
  value=dot
  break
 dot=dot+1;
for digit in n: 
 if(digit=="-"):
  minus=minus+1;
  value=value-1
  continue
 if(digit=="."):
   dott=dott+1;
   k=Decimal(1.00000000/b);
   value=1
   continue 
 for x in range(0, b+1):
  if(arr[x]==digit):
   break
 if(x == b ):
  break;
 count=count+x*index(value)
 if(dott==1):
  value=value+1;
  continue
 value=value-1
if(x == b or minus>1 or dott>1 or dot==0 or (length-dot)==1 or (dot==1 and minus>=1)):
  print "Invalid Input"
else:
 if(minus == 1):
  sys.stdout.write('-')
 if(x != b):
  print count



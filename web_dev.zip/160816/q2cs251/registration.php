<html>
<head>

<script>

error_reporting(E_ALL);
ini_set('display_errors', '1');


</script>
</head>
<body style="text-align:center">  

<h1> Registration </h1>
<br><br>
Welcome

<?php

$db = new SQLite3('mysqlitedb.db');
$name = $_POST["name"];
  $email = $_POST["email"];
  $address = $_POST["address"];
  $mobile = $_POST["mobile"];
  $account = $_POST["account"];
  $password = $_POST["password"];
  $qstr = "INSERT INTO cs251 (id,name,address,email,mobile,account,password) VALUES ('1','name', 'address', 'email', 'mobile', 'account',  'password')";
  $insres = $db->exec($qstr);


?>


</body>
</html>

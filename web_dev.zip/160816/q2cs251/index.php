
<html>
<head>
<title>Lets build stuff!</title>
<script>
function validation() {
    var name = document.forms["registration"]["name"].value;
    var mobile = document.forms["registration"]["mobile"].value;
    var address = document.forms["registration"]["address"].value;
    var account = document.forms["registration"]["account"].value;
    var password = document.forms["registration"]["password"].value;
    var name_length = name.length;
    var mobile_length = mobile.length;
    var address_length = address.length;
    var account_length = account.length;
    var password_length = password.length;
    if (name == "") {
        alert("Name must be filled out");
        return false;
    }
    
    if (mobile == "") {
        alert("mobile must be filled out");
        return false;
    }
    
    if (address == "") {
        alert("address must be filled out");
        return false;
    }
    
    if (account == "") {
        alert("account must be filled out");
        return false;
    }
    
    if (password == "") {
        alert("password must be filled out");
        return false;
    }
   
    if (name_length > 20 ) {
        alert("name must be less than 20 characters");
        return false;
    }
 
    if (password_length > 20 ) {
        alert("password must be less than 20 characters");
        return false;
    }
    if (account_length != 5 ) {
        alert("account must be 5 digit number");
        return false;
    }
    if (mobile_length != 10 ) {
        alert("mobile number  must be 10 digit number");
        return false;
    }
}
</script>
</head>
<body style="text-align:center">  
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<h1> Registration </h1>
<br>
<form name = "registration" action="registration.php" onsubmit="return validation()" method ="post" >
  Name:
  <input type="text" name="name">
  <br><br>
  Address:
  <input type="text" name="address">
  <br><br>
  Email:
  <input type="email" name="email">
  <br><br>
  Mobile Number:
  <input type="number" name="mobile">
  <br><br>
  Account Number:
  <input type="number" name="account">
  <br><br>
  Password:
  <input type="password" name="password">
  <br><br>
  <input type="submit" value="Submit">
</form>


<a href="admin.html">See All Re4gistrations</a>
</body>
</html>

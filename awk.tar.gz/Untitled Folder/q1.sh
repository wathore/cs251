#!/bin/bash
all=""
file_path=$(pwd)
directory=$1
func () {

if [ -d $1 ]
then
cd $1
folder=$(ls)
for files in $folder
do
func $files
done
cd .. 

else

if [[ $1 == *.c ]]
then
path=$(pwd) 
all="$all $path/$1"



fi


fi



}

func $directory

$file_path/./q1.awk $all
